<?php
session_start();
require_once __DIR__ . '/../functions/members_function.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'create':
        createMember();
        break;
    case 'update':
        updateMemberProcess();
        break;
    case 'delete':
        deleteMemberProcess();
        break;
    default:
        header("Location: ../view/admin/members.php?error=Hành động không hợp lệ");
        exit();
}

/** Thêm đoàn viên */
function createMember() {
    $code = trim($_POST['member_code'] ?? '');
    $name = trim($_POST['member_name'] ?? '');
    $major = trim($_POST['major_name'] ?? '');
    $class = trim($_POST['class_name'] ?? '');
    $year = trim($_POST['year'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $status = trim($_POST['status'] ?? 'active');

    if (empty($code) || empty($name) || empty($major) || empty($class) || empty($year) || empty($role)) {
        $_SESSION['error'] = 'Vui lòng điền đầy đủ thông tin!';
        header("Location: ../view/admin/members.php");
        exit();
    }

    if (addMember($code, $name, $major, $class, $year, $role, $status)) {
        $_SESSION['success'] = 'Thêm đoàn viên thành công!';
    } else {
        $_SESSION['error'] = 'Có lỗi xảy ra khi thêm đoàn viên!';
    }
    header("Location: ../view/admin/members.php");
    exit();
}

/** Cập nhật đoàn viên */
function updateMemberProcess() {
    $id = $_POST['id'] ?? '';
    $code = trim($_POST['member_code'] ?? '');
    $name = trim($_POST['member_name'] ?? '');
    $major = trim($_POST['major_name'] ?? '');
    $class = trim($_POST['class_name'] ?? '');
    $year = trim($_POST['year'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $status = trim($_POST['status'] ?? 'active');

    if (empty($id) || empty($code) || empty($name) || empty($major) || empty($class) || empty($year) || empty($role)) {
        $_SESSION['error'] = 'Vui lòng điền đầy đủ thông tin!';
        header("Location: ../view/admin/members.php");
        exit();
    }

    if (updateMember($id, $code, $name, $major, $class, $year, $role, $status)) {
        $_SESSION['success'] = 'Cập nhật đoàn viên thành công!';
    } else {
        $_SESSION['error'] = 'Có lỗi xảy ra khi cập nhật đoàn viên!';
    }
    header("Location: ../view/admin/members.php");
    exit();
}

/** Xóa đoàn viên */
function deleteMemberProcess() {
    $id = $_GET['id'] ?? '';
    if (empty($id)) {
        $_SESSION['error'] = 'Không tìm thấy ID đoàn viên!';
        header("Location: ../view/admin/members.php");
        exit();
    }

    if (deleteMember($id)) {
        $_SESSION['success'] = 'Xóa đoàn viên thành công!';
    } else {
        $_SESSION['error'] = 'Có lỗi xảy ra khi xóa đoàn viên!';
    }
    header("Location: ../view/admin/members.php");
    exit();
}
?>
