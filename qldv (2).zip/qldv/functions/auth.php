<?php
/**
 * Kiểm tra người dùng đã đăng nhập chưa
 * Nếu chưa, chuyển hướng về trang login
 */
function checkLogin($redirectPath = '../index.php') {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
        $_SESSION['error'] = 'Bạn cần đăng nhập để truy cập trang này!';
        header('Location: ' . $redirectPath);
        exit();
    }
}

/**
 * Đăng xuất người dùng
 * Xóa session và quay lại trang đăng nhập
 */
function logout($redirectPath = '../index.php') {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    session_unset();
    session_destroy();

    session_start();
    $_SESSION['success'] = 'Đăng xuất thành công!';
    header('Location: ' . $redirectPath);
    exit();
}

/**
 * Lấy thông tin user hiện tại
 */
function getCurrentUser() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    if (isset($_SESSION['user_id']) && isset($_SESSION['username'])) {
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'role' => $_SESSION['role'] ?? null
        ];
    }

    return null;
}

/**
 * Kiểm tra login (không redirect)
 */
function isLoggedIn() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    return isset($_SESSION['user_id']) && isset($_SESSION['username']);
}

/**
 * Xác thực thông tin đăng nhập
 */
function authenticateUser($conn, $username, $password) {
    $sql = "SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;

    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        // Hỗ trợ cả mật khẩu đã băm (password_hash) và mật khẩu thẳng trong DB
        if (!empty($user['password'])) {
            // Nếu password được hash bằng password_hash
            if (password_verify($password, $user['password'])) {
                mysqli_stmt_close($stmt);
                return $user;
            }

            // Fallback: so sánh thẳng (khi DB lưu mật khẩu chưa mã hóa) — tạm thời hỗ trợ
            if ($password === $user['password']) {
                mysqli_stmt_close($stmt);
                return $user;
            }
        }
    }

    if ($stmt) mysqli_stmt_close($stmt);
    return false;
}
