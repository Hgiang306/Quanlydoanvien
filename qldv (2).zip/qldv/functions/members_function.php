<?php
require_once __DIR__ . '/db_connection.php';

/**
 * Lấy danh sách đoàn viên
 */
function getAllMembers() {
    $conn = getDbConnection();
    $sql = "SELECT id, member_code, member_name, major_name, class_name, year, role, status FROM members ORDER BY member_name ASC";
    $result = mysqli_query($conn, $sql);
    $members = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $members[] = $row;
        }
    }

    mysqli_close($conn);
    return $members;
}

/**
 * Lấy thông tin đoàn viên theo ID
 */
function getMemberById($id) {
    $conn = getDbConnection();
    $sql = "SELECT * FROM members WHERE id = ? LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $member = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $member;
}

/**
 * Thêm đoàn viên
 */
function addMember($member_code, $member_name, $major_name, $class_name, $year, $role, $status = 'active') {
    $conn = getDbConnection();
    
    // Kiểm tra trùng mã số sinh viên
    $check_sql = "SELECT id FROM members WHERE member_code = ? LIMIT 1";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "s", $member_code);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        mysqli_stmt_close($check_stmt);
        mysqli_close($conn);
        return false; // Mã số đã tồn tại
    }
    mysqli_stmt_close($check_stmt);
    
    $sql = "INSERT INTO members (member_code, member_name, major_name, class_name, year, role, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssss", $member_code, $member_name, $major_name, $class_name, $year, $role, $status);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}

/**
 * Cập nhật đoàn viên
 */
function updateMember($id, $member_code, $member_name, $major_name, $class_name, $year, $role, $status = 'active') {
    $conn = getDbConnection();
    
    // Kiểm tra trùng mã số sinh viên (trừ chính nó)
    $check_sql = "SELECT id FROM members WHERE member_code = ? AND id != ? LIMIT 1";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "si", $member_code, $id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        mysqli_stmt_close($check_stmt);
        mysqli_close($conn);
        return false; // Mã số đã tồn tại
    }
    mysqli_stmt_close($check_stmt);
    
    $sql = "UPDATE members SET member_code=?, member_name=?, major_name=?, class_name=?, year=?, role=?, status=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssssssi", $member_code, $member_name, $major_name, $class_name, $year, $role, $status, $id);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}

/**
 * Xóa đoàn viên
 */
function deleteMember($id) {
    $conn = getDbConnection();
    $sql = "DELETE FROM members WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}
?>
