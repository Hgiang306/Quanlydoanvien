<?php
// Include project helpers (view/admin is two levels deep)
require_once __DIR__ . '/../../functions/auth.php';
require_once __DIR__ . '/../../functions/db_connection.php';

// Redirect if not logged in
checkLogin('/qldv/login.php');

// Get current user info
$currentUser = getCurrentUser();

// Kết nối DB
$conn = getDbConnection();

// Xử lý xóa đoàn viên
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $delete_sql = "DELETE FROM members WHERE id = $delete_id";
    if (mysqli_query($conn, $delete_sql)) {
        $_SESSION['success'] = 'Xóa đoàn viên thành công!';
    } else {
        $_SESSION['error'] = 'Có lỗi xảy ra khi xóa đoàn viên!';
    }
    header('Location: members.php');
    exit();
}

// Xử lý tìm kiếm, lọc
$search = $_GET['search'] ?? '';
$faculty = $_GET['faculty'] ?? 'all';
$status = $_GET['status'] ?? 'all';

$sql = "SELECT * FROM members WHERE 1=1";

if ($search !== '') {
  $sql .= " AND (member_name LIKE '%$search%' OR member_code LIKE '%$search%' OR major_name LIKE '%$search%')";
}
if ($faculty !== 'all') {
  $sql .= " AND major_name = '$faculty'";
}
if ($status !== 'all') {
  $sql .= " AND status = '$status'";
}

$sql .= " ORDER BY member_name ASC";

$result = mysqli_query($conn, $sql);
$faculties = mysqli_query($conn, "SELECT DISTINCT major_name FROM members ORDER BY major_name");

// Đếm tổng số đoàn viên
$total_members = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM members"))['total'];
$active_members = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM members WHERE status = 'active'"))['total'];
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quản lý đoàn viên - Khoa CNTT Đại học Đại Nam</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      --success-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
      --danger-gradient: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
      --warning-gradient: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
      --glass-bg: rgba(255, 255, 255, 0.25);
      --glass-border: rgba(255, 255, 255, 0.18);
      --shadow-soft: 0 8px 32px rgba(31, 38, 135, 0.37);
      --shadow-hover: 0 15px 35px rgba(31, 38, 135, 0.2);
    }

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      min-height: 100vh;
    }

    /* Enhanced Cards */
    .stats-card {
      background: var(--glass-bg);
      backdrop-filter: blur(10px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 1.5rem;
      transition: all 0.3s ease;
      box-shadow: var(--shadow-soft);
    }

    .stats-card:hover {
      transform: translateY(-5px);
      box-shadow: var(--shadow-hover);
    }

    .stats-icon {
      width: 60px;
      height: 60px;
      border-radius: 15px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      margin-right: 1rem;
    }

    .stats-icon.primary {
      background: var(--primary-gradient);
      color: white;
    }

    .stats-icon.success {
      background: var(--success-gradient);
      color: white;
    }

    .stats-number {
      font-size: 2rem;
      font-weight: 700;
      margin: 0;
      background: var(--primary-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    /* Enhanced Filter Section */
    .filter-section {
      background: var(--glass-bg);
      backdrop-filter: blur(15px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: var(--shadow-soft);
    }

    .search-container {
      position: relative;
    }

    .search-input {
      border: 2px solid transparent;
      border-radius: 15px;
      padding: 12px 20px 12px 50px;
      background: rgba(255, 255, 255, 0.8);
      transition: all 0.3s ease;
      font-weight: 500;
    }

    .search-input:focus {
      border-color: #667eea;
      box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
      background: white;
    }

    .search-icon {
      position: absolute;
      left: 18px;
      top: 50%;
      transform: translateY(-50%);
      color: #667eea;
      font-size: 1.1rem;
    }

    /* Enhanced Table */
    .members-table-container {
      background: var(--glass-bg);
      backdrop-filter: blur(15px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      overflow: hidden;
      box-shadow: var(--shadow-soft);
    }

    .members-table {
      margin: 0;
      background: transparent;
    }

    .members-table thead th {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 0.85rem;
      letter-spacing: 0.5px;
      padding: 1.2rem 1rem;
      border: none;
    }

    .members-table tbody tr {
      transition: all 0.3s ease;
      border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .members-table tbody tr:hover {
      background: rgba(102, 126, 234, 0.1);
      transform: scale(1.01);
    }

    .members-table td {
      padding: 1.2rem 1rem;
      vertical-align: middle;
      border: none;
    }

    /* Member Avatar */
    .member-avatar {
      width: 45px;
      height: 45px;
      border-radius: 12px;
      background: var(--primary-gradient);
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      font-weight: 600;
      margin-right: 12px;
      box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }

    /* Enhanced Badges */
    .status-badge {
      padding: 8px 16px;
      border-radius: 25px;
      font-weight: 600;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .status-active {
      background: var(--success-gradient);
      color: white;
      box-shadow: 0 4px 15px rgba(79, 172, 254, 0.3);
    }

    .status-inactive {
      background: var(--warning-gradient);
      color: #8b5a00;
      box-shadow: 0 4px 15px rgba(252, 182, 159, 0.3);
    }

    .role-badge {
      background: rgba(102, 126, 234, 0.1);
      color: #667eea;
      padding: 6px 12px;
      border-radius: 20px;
      font-weight: 500;
      font-size: 0.85rem;
    }

    /* Action Buttons */
    .action-btn {
      width: 35px;
      height: 35px;
      border-radius: 10px;
      border: none;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin: 0 3px;
      transition: all 0.3s ease;
      font-size: 0.9rem;
    }

    .action-btn.view {
      background: rgba(102, 126, 234, 0.1);
      color: #667eea;
    }

    .action-btn.edit {
      background: rgba(79, 172, 254, 0.1);
      color: #4facfe;
    }

    .action-btn.delete {
      background: rgba(250, 112, 154, 0.1);
      color: #fa709a;
    }

    .action-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    }

    /* Enhanced Modals */
    .modal-content {
      border: none;
      border-radius: 20px;
      background: var(--glass-bg);
      backdrop-filter: blur(20px);
      box-shadow: var(--shadow-soft);
    }

    .modal-header {
      background: var(--primary-gradient);
      color: white;
      border-radius: 20px 20px 0 0;
      padding: 1.5rem 2rem;
      border: none;
    }

    .modal-body {
      padding: 2rem;
    }

    .modal-footer {
      padding: 1.5rem 2rem;
      border: none;
    }

    /* Enhanced Buttons */
    .btn-primary-gradient {
      background: var(--primary-gradient);
      border: none;
      border-radius: 12px;
      padding: 12px 24px;
      font-weight: 600;
      color: white;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-primary-gradient:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(102, 126, 234, 0.6);
      color: white;
    }

    .btn-success-gradient {
      background: var(--success-gradient);
      border: none;
      border-radius: 12px;
      padding: 12px 24px;
      font-weight: 600;
      color: white;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(79, 172, 254, 0.4);
    }

    .btn-success-gradient:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(79, 172, 254, 0.6);
      color: white;
    }

    /* Form Enhancements */
    .form-control, .form-select {
      border: 2px solid transparent;
      border-radius: 12px;
      padding: 12px 16px;
      background: rgba(255, 255, 255, 0.8);
      transition: all 0.3s ease;
    }

    .form-control:focus, .form-select:focus {
      border-color: #667eea;
      box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
      background: white;
    }

    .form-label {
      font-weight: 600;
      color: #4a5568;
      margin-bottom: 8px;
    }

    /* Header Enhancement */
    .page-header {
      background: var(--glass-bg);
      backdrop-filter: blur(10px);
      border: 1px solid var(--glass-border);
      border-radius: 20px;
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: var(--shadow-soft);
    }

    .page-title {
      background: var(--primary-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      font-weight: 700;
      font-size: 2.5rem;
      margin: 0;
    }

    /* Empty State */
    .empty-state {
      text-align: center;
      padding: 4rem 2rem;
      color: #718096;
    }

    .empty-state i {
      font-size: 4rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }

    /* Animations */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .fade-in-up {
      animation: fadeInUp 0.6s ease-out;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .stats-card {
        margin-bottom: 1rem;
      }
      
      .members-table-container {
        overflow-x: auto;
      }
      
      .action-btn {
        width: 30px;
        height: 30px;
        font-size: 0.8rem;
      }
    }
  </style>
</head>
<body>

  <?php include __DIR__ . '/../sidebar.php'; ?>

  <div class="content">
    <!-- Header -->
    <div class="page-header fade-in-up">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h1 class="page-title">Quản lý đoàn viên</h1>
          <p class="text-muted mb-0">Danh sách và thông tin các đoàn viên trong hệ thống</p>
        </div>
        <button class="btn btn-primary-gradient" data-bs-toggle="modal" data-bs-target="#addMemberModal">
          <i class="fas fa-plus me-2"></i>Thêm đoàn viên
        </button>
      </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
      <div class="col-md-3">
        <div class="stats-card fade-in-up">
          <div class="d-flex align-items-center">
            <div class="stats-icon primary">
              <i class="fas fa-users"></i>
            </div>
            <div>
              <h3 class="stats-number"><?= number_format($total_members) ?></h3>
              <small class="text-muted">Tổng đoàn viên</small>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stats-card fade-in-up" style="animation-delay: 0.1s;">
          <div class="d-flex align-items-center">
            <div class="stats-icon success">
              <i class="fas fa-user-check"></i>
            </div>
            <div>
              <h3 class="stats-number"><?= number_format($active_members) ?></h3>
              <small class="text-muted">Đang hoạt động</small>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stats-card fade-in-up" style="animation-delay: 0.2s;">
          <div class="d-flex align-items-center">
            <div class="stats-icon" style="background: var(--warning-gradient); color: white;">
              <i class="fas fa-user-graduate"></i>
            </div>
            <div>
              <h3 class="stats-number"><?= mysqli_num_rows(mysqli_query($conn, "SELECT DISTINCT major_name FROM members")) ?></h3>
              <small class="text-muted">Ngành học</small>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="stats-card fade-in-up" style="animation-delay: 0.3s;">
          <div class="d-flex align-items-center">
            <div class="stats-icon" style="background: var(--danger-gradient); color: white;">
              <i class="fas fa-crown"></i>
            </div>
            <div>
              <h3 class="stats-number"><?= mysqli_num_rows(mysqli_query($conn, "SELECT id FROM members WHERE role != 'Đoàn viên'")) ?></h3>
              <small class="text-muted">Cán bộ</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Filters -->
    <div class="filter-section fade-in-up" style="animation-delay: 0.4s;">
      <form class="row g-3" method="GET">
        <div class="col-md-4">
          <div class="search-container">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="form-control search-input" name="search" 
                   placeholder="Tìm kiếm theo tên, MSSV..." value="<?= htmlspecialchars($search) ?>">
          </div>
        </div>
        <div class="col-md-3">
          <select class="form-select" name="faculty">
            <option value="all">🎓 Tất cả ngành</option>
            <?php mysqli_data_seek($faculties, 0); while($f = mysqli_fetch_assoc($faculties)): ?>
              <option value="<?= htmlspecialchars($f['major_name']) ?>" <?= $faculty == $f['major_name'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($f['major_name']) ?>
              </option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="col-md-3">
          <select class="form-select" name="status">
            <option value="all">📊 Tất cả trạng thái</option>
            <option value="active" <?= $status=='active'?'selected':'' ?>>✅ Hoạt động</option>
            <option value="inactive" <?= $status=='inactive'?'selected':'' ?>>⏸️ Ngừng hoạt động</option>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary-gradient w-100">
            <i class="fas fa-filter me-1"></i>Lọc
          </button>
        </div>
      </form>
    </div>

    <!-- Members Table -->
    <div class="members-table-container fade-in-up" style="animation-delay: 0.5s;">
      <table class="table members-table">
        <thead>
          <tr>
            <th><i class="fas fa-id-card me-2"></i>MSSV</th>
            <th><i class="fas fa-user me-2"></i>Họ tên</th>
            <th><i class="fas fa-graduation-cap me-2"></i>Ngành học</th>
            <th><i class="fas fa-users me-2"></i>Lớp</th>
            <th><i class="fas fa-calendar me-2"></i>Năm</th>
            <th><i class="fas fa-star me-2"></i>Vai trò</th>
            <th><i class="fas fa-toggle-on me-2"></i>Trạng thái</th>
            <th class="text-end"><i class="fas fa-cogs me-2"></i>Thao tác</th>
          </tr>
        </thead>
        <tbody>
          <?php if (mysqli_num_rows($result) == 0): ?>
            <tr>
              <td colspan="8" class="empty-state">
                <i class="fas fa-users"></i>
                <h5>Không tìm thấy đoàn viên nào</h5>
                <p>Hãy thử thay đổi bộ lọc hoặc thêm đoàn viên mới</p>
              </td>
            </tr>
          <?php else: ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
              <tr>
                <td><strong class="text-primary"><?= htmlspecialchars($row['member_code']) ?></strong></td>
                <td>
                  <div class="d-flex align-items-center">
                    <div class="member-avatar">
                      <?= strtoupper(substr($row['member_name'], 0, 1)) ?>
                    </div>
                    <div>
                      <div class="fw-semibold"><?= htmlspecialchars($row['member_name']) ?></div>
                      <small class="text-muted"><?= htmlspecialchars($row['member_code']) ?></small>
                    </div>
                  </div>
                </td>
                <td>
                  <span class="fw-medium"><?= htmlspecialchars($row['major_name']) ?></span>
                </td>
                <td><?= htmlspecialchars($row['class_name']) ?></td>
                <td><span class="badge bg-light text-dark"><?= htmlspecialchars($row['year']) ?></span></td>
                <td><span class="role-badge"><?= htmlspecialchars($row['role']) ?></span></td>
                <td>
                  <span class="status-badge <?= $row['status']=='active' ? 'status-active' : 'status-inactive' ?>">
                    <?= $row['status']=='active' ? '✅ Hoạt động' : '⏸️ Ngừng' ?>
                  </span>
                </td>
                <td class="text-end">
                  <button class="action-btn view" 
                          data-bs-toggle="modal" data-bs-target="#viewModal<?= $row['id'] ?>" 
                          title="Xem chi tiết">
                    <i class="fas fa-eye"></i>
                  </button>
                  <button class="action-btn edit" 
                          data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id'] ?>" 
                          title="Chỉnh sửa">
                    <i class="fas fa-edit"></i>
                  </button>
                  <a href="members.php?delete_id=<?= $row['id'] ?>" 
                     onclick="return confirm('Bạn có chắc chắn muốn xóa đoàn viên này?')" 
                     class="action-btn delete" 
                     title="Xóa">
                    <i class="fas fa-trash"></i>
                  </a>
                </td>
              </tr>
            <?php endwhile; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- M
odals -->
  <?php mysqli_data_seek($result, 0); while($row = mysqli_fetch_assoc($result)): ?>
    <!-- View Modal -->
    <div class="modal fade" id="viewModal<?= $row['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Thông tin đoàn viên</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="row">
              <div class="col-sm-4"><strong>Mã số:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['member_code']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Họ tên:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['member_name']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Ngành:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['major_name']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Lớp:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['class_name']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Năm:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['year']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Vai trò:</strong></div>
              <div class="col-sm-8"><?= htmlspecialchars($row['role']) ?></div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-4"><strong>Trạng thái:</strong></div>
              <div class="col-sm-8">
                <span class="badge <?= $row['status']=='active' ? 'badge-active' : 'badge-stop' ?>">
                  <?= $row['status']=='active' ? 'Hoạt động' : 'Ngừng hoạt động' ?>
                </span>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Chỉnh sửa đoàn viên</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <form method="POST" action="../../handle/members_process.php">
            <div class="modal-body">
              <input type="hidden" name="action" value="update">
              <input type="hidden" name="id" value="<?= $row['id'] ?>">
              
              <div class="mb-3">
                <label class="form-label">Mã số sinh viên</label>
                <input type="text" class="form-control" name="member_code" value="<?= htmlspecialchars($row['member_code']) ?>" required>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Họ tên</label>
                <input type="text" class="form-control" name="member_name" value="<?= htmlspecialchars($row['member_name']) ?>" required>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Ngành học</label>
                <input type="text" class="form-control" name="major_name" value="<?= htmlspecialchars($row['major_name']) ?>" required>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Lớp</label>
                <input type="text" class="form-control" name="class_name" value="<?= htmlspecialchars($row['class_name']) ?>" required>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Năm</label>
                <input type="number" class="form-control" name="year" value="<?= htmlspecialchars($row['year']) ?>" required>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Vai trò</label>
                <select class="form-select" name="role" required>
                  <option value="Đoàn viên" <?= $row['role']=='Đoàn viên'?'selected':'' ?>>Đoàn viên</option>
                  <option value="Bí thư chi đoàn" <?= $row['role']=='Bí thư chi đoàn'?'selected':'' ?>>Bí thư chi đoàn</option>
                  <option value="Phó bí thư" <?= $row['role']=='Phó bí thư'?'selected':'' ?>>Phó bí thư</option>
                  <option value="Ủy viên" <?= $row['role']=='Ủy viên'?'selected':'' ?>>Ủy viên</option>
                </select>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Trạng thái</label>
                <select class="form-select" name="status" required>
                  <option value="active" <?= $row['status']=='active'?'selected':'' ?>>Hoạt động</option>
                  <option value="inactive" <?= $row['status']=='inactive'?'selected':'' ?>>Ngừng hoạt động</option>
                </select>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
              <button type="submit" class="btn btn-success-gradient">
                <i class="fas fa-save me-2"></i>Cập nhật
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  <?php endwhile; ?>

  <!-- Add Member Modal -->
  <div class="modal fade" id="addMemberModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Thêm đoàn viên mới</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form method="POST" action="../../handle/members_process.php">
          <div class="modal-body">
            <input type="hidden" name="action" value="create">
            
            <div class="mb-3">
              <label class="form-label">Mã số sinh viên</label>
              <input type="text" class="form-control" name="member_code" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Họ tên</label>
              <input type="text" class="form-control" name="member_name" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Ngành học</label>
              <input type="text" class="form-control" name="major_name" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Lớp</label>
              <input type="text" class="form-control" name="class_name" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Năm</label>
              <input type="number" class="form-control" name="year" required>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Vai trò</label>
              <select class="form-select" name="role" required>
                <option value="">Chọn vai trò</option>
                <option value="Đoàn viên">Đoàn viên</option>
                <option value="Bí thư chi đoàn">Bí thư chi đoàn</option>
                <option value="Phó bí thư">Phó bí thư</option>
                <option value="Ủy viên">Ủy viên</option>
              </select>
            </div>
            
            <div class="mb-3">
              <label class="form-label">Trạng thái</label>
              <select class="form-select" name="status" required>
                <option value="active">Hoạt động</option>
                <option value="inactive">Ngừng hoạt động</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
            <button type="submit" class="btn btn-gradient">Thêm đoàn viên</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    // Show success/error messages
    <?php if (isset($_SESSION['success'])): ?>
      alert('<?= $_SESSION['success'] ?>');
      <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
      alert('<?= $_SESSION['error'] ?>');
      <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
  </script>

</body>
</html>