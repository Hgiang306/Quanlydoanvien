<?php
require_once __DIR__ . '/db_connection.php';

/**
 * Lấy danh sách đoàn viên
 */
function getAllMembers() {
    $conn = getDbConnection();
    $sql = "SELECT id, member_code, member_name, position FROM members ORDER BY id DESC";
    $result = mysqli_query($conn, $sql);
    $members = [];

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $members[] = $row;
        }
    }

    mysqli_close($conn);
    return $members;
}

/**
 * Thêm đoàn viên
 */
function addMember($member_code, $member_name, $position) {
    $conn = getDbConnection();
    $sql = "INSERT INTO members (member_code, member_name, position) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sss", $member_code, $member_name, $position);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}

/**
 * Cập nhật đoàn viên
 */
function updateMember($id, $member_code, $member_name, $position) {
    $conn = getDbConnection();
    $sql = "UPDATE members SET member_code=?, member_name=?, position=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $member_code, $member_name, $position, $id);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}

/**
 * Xóa đoàn viên
 */
function deleteMember($id) {
    $conn = getDbConnection();
    $sql = "DELETE FROM members WHERE id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id);
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    return $success;
}
?>
