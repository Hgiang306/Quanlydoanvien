<?php
$base = '/Doan/';
$current = basename($_SERVER['PHP_SELF']);
$items = [
    ['href' => $base . 'admin/dashboard.php', 'icon' => 'bi-speedometer2', 'label' => 'Tổng quan', 'active' => $current === 'dashboard.php'],
    ['href' => $base . 'views/admin/members.php', 'icon' => 'bi-people', 'label' => 'Đoàn viên', 'active' => $current === 'members.php'],
    ['href' => '#', 'icon' => 'bi-calendar-event', 'label' => 'Hoạt động', 'active' => false],
    ['href' => '#', 'icon' => 'bi-bar-chart', 'label' => 'Báo cáo', 'active' => false],
    ['href' => '#', 'icon' => 'bi-award', 'label' => 'Thành tích', 'active' => false],
];
?>

<!-- Ensure sidebar styles and icons are available (root-relative to project) -->

<link rel="stylesheet" href="/qldv/css/admin.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<aside class="sidebar" id="sidebar">
    <button class="sidebar-toggle" id="sidebarToggle" title="Thu gọn/mở rộng"><i class="bi bi-chevron-left" id="toggleIcon"></i></button>
    <div class="brand">
        <i class="bi bi-grid-1x2-fill"></i>
        <div>
            <div>Đoàn CNTT</div>
            <small>Quản trị viên</small>
        </div>
    </div>
    <nav class="menu mt-4">
        <?php foreach ($items as $it): ?>
            <a href="<?= htmlspecialchars($it['href']) ?>" class="<?= $it['active'] ? 'active' : '' ?>"><i class="bi <?= $it['icon'] ?>"></i> <span class="label"><?= htmlspecialchars($it['label']) ?></span></a>
        <?php endforeach; ?>
        <a href="<?= $base ?>handle/logout_process.php" class="mt-3"><i class="bi bi-box-arrow-right"></i> <span class="label">Đăng xuất</span></a>
    </nav>
</aside>

<script>
    const sb = document.getElementById('sidebar');
    const sbToggle = document.getElementById('sidebarToggle');
    const sbIcon = document.getElementById('toggleIcon');
    sbToggle?.addEventListener('click', () => {
        sb.classList.toggle('collapsed');
        document.body.classList.toggle('sidebar-collapsed');
        if (sb.classList.contains('collapsed')) { sbIcon.classList.replace('bi-chevron-left','bi-chevron-right'); }
        else { sbIcon.classList.replace('bi-chevron-right','bi-chevron-left'); }
    });
</script>
