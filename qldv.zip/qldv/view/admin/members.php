<?php
// Include project helpers (view/admin is two levels deep)
require_once __DIR__ . '/../../functions/auth.php';
require_once __DIR__ . '/../../functions/db_connection.php';

// Redirect if not logged in
checkLogin('/qldv/login.php');

// Kết nối DB
$conn = getDbConnection();


// Xử lý tìm kiếm, lọc
$search = $_GET['search'] ?? '';
$faculty = $_GET['faculty'] ?? 'all';
$status = $_GET['status'] ?? 'all';

$sql = "SELECT * FROM members WHERE 1=1";

if ($search !== '') {
  $sql .= " AND (member_name LIKE '%$search%' OR member_code LIKE '%$search%' OR major_name LIKE '%$search%')";
}
if ($faculty !== 'all') {
  $sql .= " AND major_name = '$faculty'";
}
if ($status !== 'all') {
  $sql .= " AND status = '$status'";
}

$result = mysqli_query($conn, $sql);
$faculties = mysqli_query($conn, "SELECT DISTINCT major_name FROM members");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Danh sách đoàn viên</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
  body { background-color: #fdf9f8; font-family: 'Segoe UI'; }
  .container { margin-top: 40px; }
  .card { border-radius: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
  .table thead { background-color: #b02a37; color: #fff; }
  .badge-active { background-color: #28a745; }
  .badge-inactive { background-color: #6c757d; }
</style>
</head>
<body>
<div class="container">
  <div class="card p-4">
    <h3 class="text-danger mb-4 text-center"><i class="fa-solid fa-users"></i> Danh sách đoàn viên</h3>

    <!-- Bộ lọc -->
    <form class="row g-3 mb-3" method="GET">
      <div class="col-md-4 position-relative">
        <input type="text" class="form-control ps-5" name="search" placeholder="Tìm kiếm theo tên, MSSV..." value="<?= htmlspecialchars($search) ?>">
        <i class="fa-solid fa-magnifying-glass position-absolute" style="left:15px; top:12px; color:#aaa;"></i>
      </div>
      <div class="col-md-3">
        <select class="form-select" name="faculty">
          <option value="all">Tất cả khoa</option>
          <?php while($f = mysqli_fetch_assoc($faculties)): ?>
            <option value="<?= $f['major_name'] ?>" <?= $faculty == $f['major_name'] ? 'selected' : '' ?>>
              <?= $f['major_name'] ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="col-md-3">
        <select class="form-select" name="status">
          <option value="all">Tất cả trạng thái</option>
          <option value="active" <?= $status=='active'?'selected':'' ?>>Hoạt động</option>
          <option value="inactive" <?= $status=='inactive'?'selected':'' ?>>Ngừng hoạt động</option>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-danger w-100"><i class="fa-solid fa-filter"></i> Lọc</button>
      </div>
    </form>

    <!-- Bảng -->
    <table class="table table-bordered align-middle">
      <thead>
        <tr>
          <th>MSSV</th>
          <th>Họ tên</th>
          <th>Ngành học</th>
          <th>Lớp</th>
          <th>Năm</th>
          <th>Vai trò</th>
          <th>Trạng thái</th>
          <th class="text-end">Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <?php if (mysqli_num_rows($result) == 0): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">Không tìm thấy đoàn viên nào</td></tr>
        <?php else: ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
              <td><?= $row['member_code'] ?></td>
              <td><?= $row['member_name'] ?></td>
              <td><?= $row['major_name'] ?></td>
              <td><?= $row['class_name'] ?></td>
              <td><?= $row['year'] ?></td>
              <td><?= $row['role'] ?></td>
              <td>
                <span class="badge <?= $row['status']=='active' ? 'badge-active' : 'badge-inactive' ?>">
                  <?= $row['status']=='active' ? 'Hoạt động' : 'Ngừng' ?>
                </span>
              </td>
              <td class="text-end">
                <button class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#viewModal<?= $row['id'] ?>"><i class="fa-solid fa-eye"></i></button>
                <a href="members_edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-pen"></i></a>
                <a href="members.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Xóa đoàn viên này?')" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-trash"></i></a>
              </td>
            </tr>

            <!-- Modal xem -->
            <div class="modal fade" id="viewModal<?= $row['id'] ?>" tabindex="-1" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Thông tin đoàn viên</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <p><b>Mã số:</b> <?= $row['member_code'] ?></p>
                    <p><b>Họ tên:</b> <?= $row['member_name'] ?></p>
                    <p><b>Ngành:</b> <?= $row['major_name'] ?></p>
                    <p><b>Lớp:</b> <?= $row['class_name'] ?></p>
                    <p><b>Năm:</b> <?= $row['year'] ?></p>
                    <p><b>Vai trò:</b> <?= $row['role'] ?></p>
                    <p><b>Trạng thái:</b> <?= $row['status'] ?></p>
                  </div>
                  <div class="modal-footer">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                  </div>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
