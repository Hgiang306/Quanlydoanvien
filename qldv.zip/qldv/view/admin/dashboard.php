<?php
// functions are located at project root: ../../functions from view/admin
require_once __DIR__ . '/../../functions/auth.php';
require_once __DIR__ . '/../../functions/db_connection.php';

// ✅ Kiểm tra đăng nhập — redirect to site login (use absolute path to avoid relative mistakes)
checkLogin('/qldv/login.php');

// ✅ Lấy thông tin user hiện tại
$currentUser = getCurrentUser();

// ✅ Lấy thống kê từ database
$conn = getDbConnection();

// Đếm tổng số đoàn viên
$totalMembersQuery = "SELECT COUNT(*) as total FROM members";
$totalMembersResult = mysqli_query($conn, $totalMembersQuery);
$totalMembers = mysqli_fetch_assoc($totalMembersResult)['total'] ?? 0;

// Đếm đoàn viên hoạt động (status = 'active')
$activeMembersQuery = "SELECT COUNT(*) as active FROM members WHERE status = 'active'";
$activeMembersResult = mysqli_query($conn, $activeMembersQuery);
$activeMembers = mysqli_fetch_assoc($activeMembersResult)['active'] ?? 0;

// Đếm đoàn viên mới trong tháng này

// Nếu bảng members không có trường created_at, bỏ các truy vấn liên quan
$newMembers = 0;
$recentMembersResult = false;

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bảng điều khiển - Khoa CNTT Đại học Đại Nam</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

  <?php include __DIR__ . '/../sidebar.php'; ?>

  <main class="content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h3 mb-1">Bảng điều khiển</h1>
        <p class="text-muted">Chào mừng trở lại, <?= htmlspecialchars($currentUser['username']) ?>!</p>
      </div>
      <div class="text-muted">
        <i class="bi bi-calendar3"></i>
        <?= date('d/m/Y') ?>
      </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row g-4 mb-4">
      <div class="col-xl-3 col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="flex-shrink-0">
                <div class="bg-primary bg-opacity-10 rounded-3 p-3">
                  <i class="bi bi-people text-primary fs-4"></i>
                </div>
              </div>
              <div class="flex-grow-1 ms-3">
                <h6 class="text-muted mb-1">Tổng đoàn viên</h6>
                <h3 class="mb-0"><?= number_format($totalMembers) ?></h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="flex-shrink-0">
                <div class="bg-success bg-opacity-10 rounded-3 p-3">
                  <i class="bi bi-person-check text-success fs-4"></i>
                </div>
              </div>
              <div class="flex-grow-1 ms-3">
                <h6 class="text-muted mb-1">Đang hoạt động</h6>
                <h3 class="mb-0"><?= number_format($activeMembers) ?></h3>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="flex-shrink-0">
                <div class="bg-info bg-opacity-10 rounded-3 p-3">
                  <i class="bi bi-person-plus text-info fs-4"></i>
                </div>
              </div>
              <div class="flex-grow-1 ms-3">
                <h6 class="text-muted mb-1">Thành viên mới</h6>
                <h3 class="mb-0"><?= number_format($newMembers) ?></h3>
                <small class="text-muted">Tháng này</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="col-xl-3 col-md-6">
        <div class="card card-soft h-100">
          <div class="card-body">
            <div class="d-flex align-items-center">
              <div class="flex-shrink-0">
                <div class="bg-warning bg-opacity-10 rounded-3 p-3">
                  <i class="bi bi-graph-up text-warning fs-4"></i>
                </div>
              </div>
              <div class="flex-grow-1 ms-3">
                <h6 class="text-muted mb-1">Tỷ lệ hoạt động</h6>
                <h3 class="mb-0"><?= $totalMembers > 0 ? round(($activeMembers / $totalMembers) * 100, 1) : 0 ?>%</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <!-- Recent Members -->
      <div class="col-lg-8">
        <div class="card card-soft">
          <div class="card-header bg-transparent border-0 pb-0">
            <div class="d-flex justify-content-between align-items-center">
              <h5 class="card-title mb-0">Đoàn viên mới nhất</h5>
              <a href="members.php" class="btn btn-sm btn-outline-primary">Xem tất cả</a>
            </div>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover">
                <thead>
                  <tr>
                    <th>Họ tên</th>
                    <th>Mã sinh viên</th>
                    <th>Ngày tham gia</th>
                    <th>Thao tác</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if ($recentMembersResult && mysqli_num_rows($recentMembersResult) > 0): ?>
                    <?php while ($member = mysqli_fetch_assoc($recentMembersResult)): ?>
                      <tr>
                        <td>
                          <div class="d-flex align-items-center">
                            <div class="avatar-sm bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2">
                              <i class="bi bi-person text-primary"></i>
                            </div>
                            <?= htmlspecialchars($member['full_name']) ?>
                          </div>
                        </td>
                        <td><?= htmlspecialchars($member['student_id']) ?></td>
                        <td><?= date('d/m/Y', strtotime($member['created_at'])) ?></td>
                        <td>
                          <a href="members.php?id=<?= $member['id'] ?>" class="btn btn-sm btn-outline-primary">
                            <i class="bi bi-eye"></i>
                          </a>
                        </td>
                      </tr>
                    <?php endwhile; ?>
                  <?php else: ?>
                    <tr>
                      <td colspan="4" class="text-center text-muted py-4">
                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                        Chưa có đoàn viên nào
                      </td>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Quick Actions & Chart -->
      <div class="col-lg-4">
        <div class="card card-soft mb-4">
          <div class="card-header bg-transparent border-0 pb-0">
            <h5 class="card-title mb-0">Thao tác nhanh</h5>
          </div>
          <div class="card-body">
            <div class="d-grid gap-2">
              <a href="members.php?action=add" class="btn btn-primary">
                <i class="bi bi-person-plus me-2"></i>Thêm đoàn viên
              </a>
              <a href="#" class="btn btn-outline-primary">
                <i class="bi bi-calendar-event me-2"></i>Tạo hoạt động
              </a>
              <a href="#" class="btn btn-outline-primary">
                <i class="bi bi-file-earmark-text me-2"></i>Xuất báo cáo
              </a>
            </div>
          </div>
        </div>

        <!-- Activity Chart -->
        <div class="card card-soft">
          <div class="card-header bg-transparent border-0 pb-0">
            <h5 class="card-title mb-0">Thống kê hoạt động</h5>
          </div>
          <div class="card-body">
            <canvas id="activityChart" width="400" height="200"></canvas>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Activity Chart
    const ctx = document.getElementById('activityChart').getContext('2d');
    const activityChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Hoạt động', 'Không hoạt động'],
        datasets: [{
          data: [<?= $activeMembers ?>, <?= $totalMembers - $activeMembers ?>],
          backgroundColor: ['#198754', '#dee2e6'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              usePointStyle: true
            }
          }
        }
      }
    });
  </script>

</body>
</html>