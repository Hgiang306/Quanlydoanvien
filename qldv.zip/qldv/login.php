<?php
session_start();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập - Quản lý đoàn viên</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav>
        <a href="index.php"><img src="images/about.jpg" style="width:100px; height:auto;" alt="Logo Đoàn khoa"></a>
    </nav>
    <div class="form-wrapper">
        <h2>Đăng nhập</h2>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo htmlentities($_SESSION['error']); unset($_SESSION['error']); ?></div>
        <?php endif; ?>
        <?php if (!empty($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo htmlentities($_SESSION['success']); unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form action="handle/login_process.php" method="post">
            <div class="form-control">
                <input type="text" name="username" id="username" required>
                <label>Tên đăng nhập</label>
            </div>
            <div class="form-control">
                <input type="password" name="password" id="password" required>
                <label>Mật khẩu</label>
            </div>
            <button type="submit" name="login">Đăng nhập</button>
            <div class="form-help"> 
                <div class="remember-me">
                    <input type="checkbox" id="remember-me">
                    <label for="remember-me">Ghi nhớ tôi</label>
                </div>
                <a href="#">Cần trợ giúp?</a>
            </div>
        </form>
        <small>
            This page is protected by Hgiang 
            <a href="#">Learn more.</a>
        </small>
    </div>

</body>
</html>