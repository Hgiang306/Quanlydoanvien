<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

     <title>Quản lý đoàn viên CNTT</title>
<!-- 

Eatery Cafe Template 

http://www.templatemo.com/tm-515-eatery

-->
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

     <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
     <link rel="stylesheet" href="css/animate.css">
     <link rel="stylesheet" href="css/owl.carousel.css">
     <link rel="stylesheet" href="css/owl.theme.default.min.css">
     <link rel="stylesheet" href="css/magnific-popup.css">

     <!-- MAIN CSS -->
     <link rel="stylesheet" href="css/templatemo-style.css">

</head>
<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="index.html" class="navbar-brand">Đoàn Khoa <span>.</span> Công Nghệ Thông Tin</a>
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="#home" class="smoothScroll">Trang chủ</a></li>
                         <li><a href="#about" class="smoothScroll">Giới thiệu</a></li>
                         <li><a href="#menu" class="smoothScroll">Sự kiện</a></li>
                         <li><a href="#contact" class="smoothScroll">Liên hệ</a></li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                         <a href="login.php" class="section-btn">Đăng nhập</a>
                    </ul>
               </div>

          </div>
     </section>


     <!-- HOME -->
     <section id="home" class="slider" data-stellar-background-ratio="0.5">
          <div class="row">

                    <div class="owl-carousel owl-theme">
                         <div class="item item-first">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-8 col-sm-12">
                                             <h3>Trường Đại Học Đại Nam</h3>
                                             <h1>Liên Chi Đoàn Khoa Công Nghệ Thông Tin</h1>
                                             <a href="#team" class="section-btn btn btn-default smoothScroll">Tìm hiểu thêm</a>
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-second">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-8 col-sm-12">
                                             
                                        </div>
                                   </div>
                              </div>
                         </div>

                         <div class="item item-third">
                              <div class="caption">
                                   <div class="container">
                                        <div class="col-md-8 col-sm-12">
                                        
                                        </div>
                                   </div>
                              </div>
                         </div>
                    </div>

          </div>
     </section>


     <!-- ABOUT -->
     <section id="about" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="about-info">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.2s">
                                   <h4>CHÚNG TÔI LÀ</h4>
                                   <h2>Đoàn Khoa Công Nghệ Thông Tin</h2>
                                   <h2>Trường Đại Học Đại Nam</h2>
                              </div>

                              <div class="wow fadeInUp" data-wow-delay="0.4s">
                                   <p>Trường Đại học Đại Nam xác định mục tiêu đào tạo định hướng ứng dụng nghề nghiệp ở những lĩnh vực: Kinh tế - Kinh doanh; Kỹ thuật – Công nghệ; Khoa học Xã hội, Sức khỏe và Ngoại ngữ.</p>
                                   <p>Đào tạo để người học ra trường có cuộc sống tốt và là công dân tốt; góp phần thúc đẩy mạnh mẽ nền giáo dục đại học nước nhà. </p>
                                   <p>Đến năm 2030, trở thành địa chỉ đào tạo tin cậy hàng đầu trong khối các trường đại học tại Việt Nam, là lựa chọn hàng đầu của người học với các ngành đang đào tạo tại nhà trường.</p>
                              </div>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="wow fadeInUp about-image" data-wow-delay="0.6s">
                              <img src="images/about.jpg" class="img-responsive" alt="">
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- TEAM -->
     <section id="team" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title wow fadeInUp" data-wow-delay="0.1s">
                              <h2>Thành viên cốt cán của LCD</h2>
                              <h4>Khoa Công Nghệ Thông Tin</h4>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb wow fadeInUp" data-wow-delay="0.2s">
                              <img src="images/member3.jpg" class="img-responsive" alt="">
                                   <div class="team-hover">
                                        <div class="team-item">
                                             <h4>Nếu có việc gì hãy liên hệ qua đây!</h4> 
                                             <ul class="social-icon">
                                                  <li><a href="#" class="fa fa-phone"></a></li>
                                                  <li><a href="#" class="fa fa-envelope-o"></a></li>
                                             </ul>
                                        </div>
                                   </div>
                         </div>
                         <div class="team-info">
                              <h3>ThS. Lê Tuấn Anh</h3>
                              <p>P. Bí thư LCĐ Khoa</p>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb wow fadeInUp" data-wow-delay="0.4s">
                              <img src="images/member2.jpg" class="img-responsive" alt="">
                                   <div class="team-hover">
                                        <div class="team-item">
                                             <h4>Nếu có việc gì hãy liên hệ qua đây!</h4>
                                             <ul class="social-icon">
                                                  <li><a href="#" class="fa fa-phone"></a></li>
                                                  <li><a href="#" class="fa fa-envelope-o"></a></li>
                                             </ul>
                                        </div>
                                   </div>
                         </div>
                         <div class="team-info">
                              <h3>ThS. Lê Văn Phong</h3>
                              <p>Bí thư LCĐ Khoa</p>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="team-thumb wow fadeInUp" data-wow-delay="0.6s">
                              <img src="images/member4.jpg" class="img-responsive" alt="">
                                   <div class="team-hover">
                                        <div class="team-item">
                                             <h4>Nếu có việc gì hãy liên hệ qua đây!</h4>
                                             <ul class="social-icon">
                                                  <li><a href="#" class="fa fa-phone"></a></li>
                                                  <li><a href="#" class="fa fa-envelope-o"></a></li>
                                             </ul>
                                        </div>
                                   </div>
                         </div>
                         <div class="team-info">
                              <h3>CN. Nguyễn Thái Khánh</h3>
                              <p>P Bí thư LCĐ Khoa</p>
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>


     <!-- EVENT-->
     <section id="menu" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title wow fadeInUp" data-wow-delay="0.1s">
                              <h2>Sự Kiện</h2>
                              <h4>Một số sự kiện của khoa CNTT</h4>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event2.jpg" class="image-popup" title="American Breakfast">
                                   <img src="images/event2.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>TRĂNG HIẾU NGHĨA – SÁNG MÃI YÊU THƯƠNG</h3>
                                             <p>Sáng ngày 14/9/2025, LCD Khoa Công nghệ thông tin đã tổ chức chương trình thiện nguyện đầy ý nghĩa “Trăng Hiếu nghĩa – Sáng yêu thương” tại Trung tâm chăm sóc người khuyết tật Hà Nội.</p>
                                        </div>
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event1.jpg" class="image-popup" title="Self-made Salad">
                                   <img src="images/event1.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>Let’s Dance Season 7</h3>
                                             <p> Khoa Công nghệ Thông tin mang đến tiết mục “𝐕𝐨̣𝐧𝐠 𝐮̛𝐨̛́𝐜 𝐭𝐮̛̣ 𝐝𝐨” – một hành trình nghệ thuật đầy cảm xúc, tái hiện tinh thần kiên cường trong chiến tranh và khát vọng hòa bình, tự do của dân tộc Việt Nam.</p>
                                        </div>
                                        
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event6.jpg" class="image-popup" title="Chinese Noodle">
                                   <img src="images/event6.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>VINH DANH LIÊN CHI ĐOÀN KHOA CÔNG NGHỆ THÔNG TIN</h3>
                                             <p>Lễ Vinh danh Tập thể và cá nhân có thành tích xuất sắc trong hoạt động Đoàn và phong trào thanh niên năm học 2024–2025! Đây là sự ghi nhận xứng đáng cho những nỗ lực không ngừng.</p>
                                        </div>
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event4.jpg" class="image-popup" title="Rice Soup">
                                   <img src="images/event4.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>Chào mừng 90 năm thành lập Đoàn Thanh Niên Cộng Sản Hồ Chí Minh</h3>
                                             <p>Green / Chicken</p>
                                        </div>
                                        
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event5.jpg" class="image-popup" title="Project title">
                                   <img src="images/event5.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>Một giọt hòng trao đi - một cuộc đời ở lại</h3>
                                             <p>Các bạn đã chứng minh rằng tuổi trẻ Đại Nam không chỉ giỏi học tập, năng động sáng tạo, mà còn biết sẻ chia và sẵn sàng cho đi để cứu người.</p>
                                        </div>
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- MENU THUMB -->
                         <div class="menu-thumb">
                              <a href="images/event3.jpg" class="image-popup" title="Project title">
                                   <img src="images/event3.jpg" class="img-responsive" alt="">

                                   <div class="menu-info">
                                        <div class="menu-item">
                                             <h3>Đoàn viên khoa Công Nghệ Thông Tin chung tay phổ cập Kỹ Năng Số</h3>
                                             <p>Chiều nay 11/8/2025 , một số đoàn viên Liên chi Đoàn Khoa Công nghệ thông tin – Trường Đại học Đại Nam đã tham gia mô hình “Thanh niên chung tay phổ cập kỹ năng số” trong khuôn khổ buổi phát động phong trào "Bình dân học vụ số" tại UBND Phường Phú Lương, TP. Hà Nội.</p>
                                        </div>
                                   </div>
                              </a>
                         </div>
                    </div>


               </div>
          </div>
     </section>

     <!-- CONTACT -->
     <section id="contact" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">
	<!-- How to change your own map point
            1. Go to Google Maps
            2. Click on your location point
            3. Click "Share" and choose "Embed map" tab
            4. Copy only URL and paste it within the src="" field below
	-->
                    <div class="wow fadeInUp col-md-6 col-sm-12" data-wow-delay="0.4s">
                         <div id="google-map">
                              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3726.120607396643!2d105.7552135750291!3d20.947671180681507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313452eaa9c461c3%3A0x2a3e1c421f299adc!2zVHLGsOG7nW5nIMSQ4bqhaSBI4buNYyDEkOG6oWkgTmFt!5e0!3m2!1svi!2s!4v1762371401662!5m2!1svi!2s" allowfullscreen></iframe>
                         </div>
                    </div>    

                    <div class="col-md-6 col-sm-12">

                         <div class="col-md-12 col-sm-12">
                              <div class="section-title wow fadeInUp" data-wow-delay="0.1s">
                                   <h2>Liên Hệ</h2>
                              </div>
                         </div>

                         <!-- CONTACT FORM -->
                         <form action="#" method="post" class="wow fadeInUp" id="contact-form" role="form" data-wow-delay="0.8s">

                              <!-- IF MAIL SENT SUCCESSFUL  // connect this with custom JS -->
                              <h6 class="text-success">Your message has been sent successfully.</h6>
                              
                              <!-- IF MAIL NOT SENT -->
                              <h6 class="text-danger">E-mail must be valid and message must be longer than 1 character.</h6>

                              <div class="col-md-6 col-sm-6">
                                   <input type="text" class="form-control" id="cf-name" name="name" placeholder="Họ tên ">
                              </div>

                              <div class="col-md-6 col-sm-6">
                                   <input type="email" class="form-control" id="cf-email" name="email" placeholder="Mã sinh viên">
                              </div>

                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" id="cf-subject" name="subject" placeholder="Bạn muốn nói gì?">

                                   <button type="submit" class="form-control" id="cf-submit" name="submit">Gửi</button>
                              </div>
                         </form>
                    </div>

               </div>
          </div>
     </section>          


     <!-- FOOTER -->
     <footer id="footer" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-4 col-sm-4">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2 class="wow fadeInUp" data-wow-delay="0.2s">Liên hệ</h2>
                              </div>
                              <address class="wow fadeInUp" data-wow-delay="0.4s">
                                   <p>Số 1 Phố Xốm, Phú Lãm, Hà Đông, Hà Nội <br> (024) 35577799<br>support@dainam.edu.vn</p>
                              </address>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <div class="footer-info">
                              <div class="section-title">
                                   <h2 class="wow fadeInUp" data-wow-delay="0.2s">Hỗ trợ sinh viên</h2>
                              </div>
                              <address class="wow fadeInUp" data-wow-delay="0.4s">
                                   <p>Thông báo sự kiện</p>
                                   <p>Quản lý đoàn viên</p>
                                   <p>Rút sổ đoàn</p>
                              </address>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-4">
                         <ul class="wow fadeInUp social-icon" data-wow-delay="0.4s">
                              <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                              <li><a href="#" class="fa fa-twitter"></a></li>
                              <li><a href="#" class="fa fa-instagram"></a></li>
                              <li><a href="#" class="fa fa-google"></a></li>
                         </ul>

                         <div class="wow fadeInUp copyright-text" data-wow-delay="0.8s"> 
                              <p><br>Copyright &copy; 2018 <br>Your Company Name 
                              
                              <br><br>Design: <a rel="nofollow" href="http://templatemo.com" target="_parent">Hương Giang</a> 
                              <br><br>Distribution: <a href="http://themewagon.com" target="_parent">ThemeWagon</a></p>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>


     <!-- SCRIPTS -->
     <script src="js/jquery.js"></script>
     <script src="js/bootstrap.min.js"></script>
     <script src="js/jquery.stellar.min.js"></script>
     <script src="js/wow.min.js"></script>
     <script src="js/owl.carousel.min.js"></script>
     <script src="js/jquery.magnific-popup.min.js"></script>
     <script src="js/smoothscroll.js"></script>
     <script src="js/custom.js"></script>

</body>
</html>