<?php
require_once __DIR__ . '/../functions/members_function.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {
    case 'create':
        createMember();
        break;
    case 'update':
        updateMemberProcess();
        break;
    case 'delete':
        deleteMemberProcess();
        break;
    default:
        header("Location: ../view/admin/members.php?error=Hành động không hợp lệ");
        exit();
}

/** Thêm đoàn viên */
function createMember() {
    $code = trim($_POST['member_code'] ?? '');
    $name = trim($_POST['member_name'] ?? '');
    $pos  = trim($_POST['position'] ?? '');

    if (empty($code) || empty($name) || empty($pos)) {
        header("Location: ../view/admin/members.php?error=Thiếu thông tin");
        exit();
    }

    if (addMember($code, $name, $pos)) {
        header("Location: ../view/admin/members.php?success=Thêm thành công");
    } else {
        header("Location: ../view/admin/members.php?error=Lỗi khi thêm");
    }
}

/** Cập nhật đoàn viên */
function updateMemberProcess() {
    $id   = $_POST['id'] ?? '';
    $code = trim($_POST['member_code'] ?? '');
    $name = trim($_POST['member_name'] ?? '');
    $pos  = trim($_POST['position'] ?? '');

    if (empty($id) || empty($code) || empty($name)) {
        header("Location: ../view/admin/members.php?error=Thiếu dữ liệu");
        exit();
    }

    if (updateMember($id, $code, $name, $pos)) {
        header("Location: ../view/admin/members.php?success=Cập nhật thành công");
    } else {
        header("Location: ../view/admin/members.php?error=Lỗi khi cập nhật");
    }
}

/** Xóa đoàn viên */
function deleteMemberProcess() {
    $id = $_GET['id'] ?? '';
    if (empty($id)) {
        header("Location: ../view/admin/members.php?error=Không có ID");
        exit();
    }

    if (deleteMember($id)) {
        header("Location: ../view/admin/members.php?success=Xóa thành công");
    } else {
        header("Location: ../view/admin/members.php?error=Lỗi khi xóa");
    }
}
?>
