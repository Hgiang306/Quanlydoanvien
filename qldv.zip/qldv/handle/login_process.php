<?php
session_start();
require_once '../functions/db_connection.php';
require_once '../functions/auth.php'; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    handleLogin();
}

function handleLogin() {
    $conn = getDbConnection();
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Debug helper: append lightweight info to a log file (do not log actual passwords)
    $logFile = __DIR__ . '/login_debug.log';
    $log = function($message, $data = []) use ($logFile) {
        $time = date('Y-m-d H:i:s');
        $entry = "[$time] $message";
        if (!empty($data)) {
            $entry .= ' | ' . json_encode($data, JSON_UNESCAPED_UNICODE);
        }
        file_put_contents($logFile, $entry . PHP_EOL, FILE_APPEND);
    };

    $log('Attempt login', ['username' => $username]);

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = 'Vui lòng nhập đầy đủ username và password!';
        $log('Missing fields, redirect to login');
        header('Location: ../login.php');
        exit();
    }

    $user = authenticateUser($conn, $username, $password);
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['success'] = 'Đăng nhập thành công!';
        mysqli_close($conn);
        // Điều hướng theo quyền
    // Redirect targets: admin pages are in ../admin/, member pages remain under view/member
    // Admin pages are under view/admin/ so redirect there to avoid 404
    $target = (strtolower($user['role'] ?? '') === 'admin') ? '../view/admin/dashboard.php' : '../view/member/home.php';
        $log('Authentication success', ['username' => $user['username'], 'role' => $user['role'], 'redirect' => $target]);
        header('Location: ' . $target);
        exit();
    }

    // Nếu authenticateUser trả về false, kiểm tra xem username có tồn tại trong DB không
    $stmt = mysqli_prepare($conn, "SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        if ($res && mysqli_num_rows($res) > 0) {
            $row = mysqli_fetch_assoc($res);
            $pwHash = $row['password'];
            $matchesHash = false;
            $matchesPlain = false;
            if (!empty($pwHash)) {
                // không log mật khẩu, chỉ log kết quả so khớp
                $matchesHash = password_verify($password, $pwHash);
                $matchesPlain = ($password === $pwHash);
            }
            $log('Authentication failed - user exists', ['username' => $username, 'role' => $row['role'], 'matchesHash' => $matchesHash, 'matchesPlain' => $matchesPlain]);
        } else {
            $log('Authentication failed - user not found', ['username' => $username]);
        }
        mysqli_stmt_close($stmt);
    } else {
        $log('Authentication failed - could not prepare user lookup');
    }

    $_SESSION['error'] = 'Tên đăng nhập hoặc mật khẩu không đúng!';
    mysqli_close($conn);
    $log('Redirecting back to login due to failed authentication');
    header('Location: ../login.php');
    exit();
}
?>