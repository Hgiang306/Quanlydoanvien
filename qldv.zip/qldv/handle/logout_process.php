<?php
require_once __DIR__ . '/../functions/auth.php';

// Sử dụng hàm logout chung
logout('../index.php');
?>
